<?php 

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Locomocao.php");

class LocomocaoDAO {
    
    public function list() {
        $sql = "SELECT * FROM locomocao";
        $conn = Connection::getConnection();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $dados = $stmt->fetchAll();
        return $this->map($dados);
         
    }
    
    private function map(array $dados) {
        $locomocoes = [];    
        foreach ($dados as $d) {          
            $locomocao = new Locomocao();
            $locomocao->setId($d['id']);
            $locomocao->setLocomocao($d['locomocao']);

            array_push($locomocoes, $locomocao);
        }
        
        return $locomocoes;
    }
}
