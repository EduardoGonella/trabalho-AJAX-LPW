<?php 

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Periodo.php");

class PeriodoDAO {
    
    public function list() {
        $sql = "SELECT * FROM periodo";
        $conn = Connection::getConnection();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $dados = $stmt->fetchAll();
        return $this->map($dados);
         
    }
    
    private function map(array $dados) {
        $periodos = [];    
        foreach ($dados as $d) {          
            $periodo = new Periodo();
            $periodo->setId($d['id']);
            $periodo->setPeriodo($d['periodo']);

            array_push($periodos, $periodo);
        }
        
        return $periodos;
    }
}