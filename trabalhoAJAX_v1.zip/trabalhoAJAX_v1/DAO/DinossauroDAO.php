<?php 

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Dinossauro.php");
require_once(__DIR__ . "/../model/Dieta.php");
require_once(__DIR__ . "/../model/Locomocao.php");
require_once(__DIR__ . "/../model/Periodo.php");


class DinossauroDAO {
    
    public function list() {
       
        $sql = "SELECT dino.*, d.dieta, l.locomocao, p.periodo 
                FROM dinossauro as dino 
                JOIN dieta as d ON (d.id = dino.id_dieta)
                JOIN locomocao as l ON (l.id = dino.id_locomocao)
                JOIN periodo as p ON (p.id = dino.id_periodo)";
        $conn = Connection::getConnection();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $dados = $stmt->fetchAll();
        return $this->map($dados);
         
    }
    
    public function findById(int $id): ?Dinossauro {
        $sql = "SELECT dino.*, d.dieta, l.locomocao, p.periodo 
                FROM dinossauro as dino
                JOIN dieta as d ON (d.id = dino.id_dieta)
                JOIN locomocao as l ON (l.id = dino.id_locomocao)
                JOIN periodo as p ON (p.id = dino.id_periodo)
                WHERE dino.id = ?";
        
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        
        $dados = $stm->fetchAll();
        $dinossauros = $this->map($dados);

        if(! empty($dinossauros))
            return $dinossauros[0];
        else
            return NULL;
    }
    
    public function insert(Dinossauro $dinossauro) {
        try{
        $sql = "INSERT INTO dinossauro (nome, altura, comprimento, velocidade, id_dieta, id_locomocao, id_periodo, foto)
        VALUES (:nome, :altura, :comprimento, :velocidade, :id_dieta, :id_locomocao, :id_periodo, :foto)";
            $conn = Connection::getConnection();
            $stmt = $conn->prepare($sql);
            $stmt->bindValue("nome", $dinossauro->getNome());
            $stmt->bindValue("altura", $dinossauro->getAltura());
            $stmt->bindValue("comprimento", $dinossauro->getComprimento());
            $stmt->bindValue("velocidade", $dinossauro->getVelocidade());
            $stmt->bindValue("id_dieta", $dinossauro->getIdDieta()->getId());
            $stmt->bindValue("id_locomocao", $dinossauro->getIdLocomocao()->getId());
            $stmt->bindValue("id_periodo", $dinossauro->getIdPeriodo()->getId());
            $stmt->bindValue("foto", $dinossauro->getFoto());
            $stmt->execute();
            return "";
        } catch (PDOException $e) {
            $erro = "Erro ao salvar o dinossauro. tente novamente.";
            if(AMB_DEV) {
                $erro .= "<br>" . $e->getMessage();
            }
            return $erro;
        }
    }
    
    public function update(Dinossauro $dinossauro) {
        try {
            $sql = "UPDATE dinossauro 
                    SET nome = :nome, altura = :altura, comprimento = :comprimento, velocidade = :velocidade,
                    id_dieta = :id_dieta, id_locomocao = :id_locomocao, id_periodo = :id_periodo, foto = :foto
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $dinossauro->getNome());
            $stm->bindValue("altura", $dinossauro->getAltura());
            $stm->bindValue("comprimento", $dinossauro->getComprimento());
            $stm->bindValue("velocidade", $dinossauro->getVelocidade());
            $stm->bindValue("id_dieta", $dinossauro->getIdDieta()->getId());
            $stm->bindValue("id_locomocao", $dinossauro->getIdLocomocao()->getId());
            $stm->bindValue("id_periodo", $dinossauro->getIdPeriodo()->getId());
            $stm->bindValue("foto", $dinossauro->getFoto());
            $stm->bindValue("id", $dinossauro->getId());

            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o dinossauro. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }
    
    public function exclude($id_excluir){
        try {
            $sql = "DELETE FROM dinossauro WHERE id = ?";
            
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id_excluir]);
            return "";

        } catch(PDOException $e) {
            $erro = "Erro ao excluir o dinossauro. Tente novamente.";
            if(AMB_DEV)
                $erro .= "<br>" . $e->getMessage();  
            return $erro;
        }
    }

    private function map(array $dados) {
    $dinossauros = [];    
    foreach ($dados as $d) {
            $dinossauro = new Dinossauro();
            $dinossauro->setId($d['id']);
            $dinossauro->setNome($d['nome']);
            $dinossauro->setAltura($d['altura']);
            $dinossauro->setComprimento($d['comprimento']);
            $dinossauro->setVelocidade($d['velocidade']);
            $dinossauro->setFoto($d['foto']);
            
            $dieta = new Dieta();
            $dieta->setId($d['id_dieta']);
            $dieta->setDieta($d['dieta']);
            $dinossauro->setIdDieta($dieta);

            $locomocao = new Locomocao();
            $locomocao->setId($d['id_dieta']);
            $locomocao->setLocomocao($d['locomocao']);
            $dinossauro->setIdLocomocao($locomocao);

            $periodo = new Periodo();
            $periodo->setId($d['id_periodo']);
            $periodo->setPeriodo($d['periodo']);
            $dinossauro->setIdPeriodo($periodo);
            
            array_push($dinossauros, $dinossauro);
        }
        
        return $dinossauros;
    }
}