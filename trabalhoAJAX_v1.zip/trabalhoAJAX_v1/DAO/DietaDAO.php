<?php 

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Dieta.php");

class DietaDAO {
    
    public function list() {
        $sql = "SELECT * FROM dieta";
        $conn = Connection::getConnection();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $dados = $stmt->fetchAll();
        return $this->map($dados);
         
    }
    
    private function map(array $dados) {
        $dietas = [];    
        foreach ($dados as $d) {          
            $dieta = new Dieta();
            $dieta->setId($d['id']);
            $dieta->setDieta($d['dieta']);

            array_push($dietas, $dieta);
        }
        
        return $dietas;
    }
}