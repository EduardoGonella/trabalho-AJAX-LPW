<?php

require_once(__DIR__ . "/Dieta.php");
require_once(__DIR__ . "/Locomocao.php");
require_once(__DIR__ . "/Periodo.php");

class Dinossauro {
    private ?int $id;
    private ?string $nome;
    private ?float $altura;
    private ?float $comprimento;
    private ?int $velocidade;
    private ?Dieta $idDieta;
    private ?Locomocao $idLocomocao;
    private ?Periodo $idPeriodo;
    private ?string $foto;

    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome(): ?string
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of altura
     */
    public function getAltura(): ?float
    {
        return $this->altura;
    }

    /**
     * Set the value of altura
     */
    public function setAltura(?float $altura): self
    {
        $this->altura = $altura;

        return $this;
    }

    /**
     * Get the value of comprimento
     */
    public function getComprimento(): ?float
    {
        return $this->comprimento;
    }

    /**
     * Set the value of comprimento
     */
    public function setComprimento(?float $comprimento): self
    {
        $this->comprimento = $comprimento;

        return $this;
    }

    /**
     * Get the value of velocidade
     */
    public function getVelocidade(): ?int
    {
        return $this->velocidade;
    }

    /**
     * Set the value of velocidade
     */
    public function setVelocidade(?int $velocidade): self
    {
        $this->velocidade = $velocidade;

        return $this;
    }

    /**
     * Get the value of idDieta
     */
    public function getIdDieta(): ?Dieta
    {
        return $this->idDieta;
    }

    /**
     * Set the value of idDieta
     */
    public function setIdDieta(?Dieta $idDieta): self
    {
        $this->idDieta = $idDieta;

        return $this;
    }

    /**
     * Get the value of idLocomocao
     */
    public function getIdLocomocao(): ?Locomocao
    {
        return $this->idLocomocao;
    }

    /**
     * Set the value of idLocomocao
     */
    public function setIdLocomocao(?Locomocao $idLocomocao): self
    {
        $this->idLocomocao = $idLocomocao;

        return $this;
    }

    /**
     * Get the value of idPeriodo
     */
    public function getIdPeriodo(): ?Periodo
    {
        return $this->idPeriodo;
    }

    /**
     * Set the value of idPeriodo
     */
    public function setIdPeriodo(?Periodo $idPeriodo): self
    {
        $this->idPeriodo = $idPeriodo;

        return $this;
    }
    
    public function getFoto(): ?string
    {
        return $this->foto;
    }

    /**
     * Set the value of nome
     */
    public function setFoto(?string $foto): self
    {
        $this->foto = $foto;

        return $this;
    }
}
?>