<?php

class Periodo {
    private ?int $id;
    private ?string $periodo = null;

    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of periodo
     */
    public function getPeriodo(): ?string
    {
        return $this->periodo;
    }

    public function getPeriodoDesc(): ?string
    {
        // T=Triássico, J=Jurássico, C=Cretáceo
        if ($this->periodo === 'T') {
            return 'Triássico';
        } elseif ($this->periodo === 'J') {
            return 'Jurássico';
        } elseif ($this->periodo === 'C') {
            return 'Cretáceo';
        }
        
        return "";
    }
    
    /**
     * Set the value of periodo
     */
    public function setPeriodo(?string $periodo): self
    {
        $this->periodo = $periodo;

        return $this;
    }
}

?>