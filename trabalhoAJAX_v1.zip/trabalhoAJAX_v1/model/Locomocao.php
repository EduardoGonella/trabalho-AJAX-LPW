<?php

Class Locomocao {
    private ?int $id;
    private ?string $locomocao = null;

    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of locomocao
     */
    public function getLocomocao(): ?string
    {
        return $this->locomocao;
    }

    public function getLocomocaoDesc(): ?string
    {
        // T=Terrestre, W=Aquático, A=Aéreo
        if ($this->locomocao === 'T') {
            return 'Terrestre';
        } elseif ($this->locomocao === 'W') {
            return 'Aquático';
        } elseif ($this->locomocao === 'A') {
            return 'Aéreo';
        }
        
        return "";
    }

    /**
     * Set the value of locomocao
     */
    public function setLocomocao(?string $locomocao): self
    {
        $this->locomocao = $locomocao;

        return $this;
    }
}