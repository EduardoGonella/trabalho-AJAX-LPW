<?php

Class Dieta {
    private ?int $id;
    private ?string $dieta = null;

    /**
     * Get the value of id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of dieta
     */
    public function getDieta()
    {
        return $this->dieta;
    }

    public function getDietaDesc(): ?string
    {
        // C=Carnívoro, H=Herbívoro, O=Onívoro
        if ($this->dieta === 'C') {
            return 'Carnívoro';
        } elseif ($this->dieta === 'H') {
            return 'Herbívoro';
        } elseif ($this->dieta === 'O') {
            return 'Onívoro';
        }
        
        return "";
    }

    /**
     * Set the value of dieta
     */
    public function setDieta($dieta): self
    {
        $this->dieta = $dieta;

        return $this;
    }
}