<?php

require_once( __DIR__ . "/../DAO/PeriodoDAO.php");

class PeriodoController {
    
    public function listar() {
        $periodoDAO = new PeriodoDAO();
        return $periodoDAO->list();
    }
}

?>