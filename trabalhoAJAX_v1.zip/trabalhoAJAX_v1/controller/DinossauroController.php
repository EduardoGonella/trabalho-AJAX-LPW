<?php

require_once( __DIR__ . "/../DAO/DinossauroDAO.php");
require_once( __DIR__ . "/../service/DinossauroService.php");

class DinossauroController {
    
    private DinossauroDAO $dinossauroDAO;
    private DinossauroService $dinossauroService;
    
    public function __construct() {
        $this->dinossauroDAO = new DinossauroDAO();
        $this->dinossauroService = new DinossauroService();
    }
    
    public function listar() {
        return $this->dinossauroDAO->list();
    }
    
    public function buscarPorId(int $id) {
        return $this->dinossauroDAO->findById($id);
    }
    
    public function excluir($id_excluir) {
        $this->dinossauroDAO->exclude($id_excluir);
    }
    
    public function alterar($dinossauro) {
        // Validar os dados
        $erros = $this->dinossauroService->validar($dinossauro);
        
        // Persistir os dados
        if (empty($erros)) {
            $erroDAO = $this->dinossauroDAO->update($dinossauro);
            
            if ($erroDAO) {
                array_push($erros, $erroDAO);
            }
        }
        
        return $erros;       
    }
    
    public function inserir($dinossauro) {
        // Validar os dados
        $erros = $this->dinossauroService->validar($dinossauro);
        
        // Persistir os dados
        if (empty($erros)) {
            $erroDAO = $this->dinossauroDAO->insert($dinossauro);
            
            if ($erroDAO) {
                array_push($erros, $erroDAO);
            }
        }
        
        return $erros;       
    }
}

?>