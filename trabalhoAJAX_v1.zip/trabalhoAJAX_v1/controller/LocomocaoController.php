<?php

require_once( __DIR__ . "/../DAO/LocomocaoDAO.php");

class LocomocaoController {
    
    public function listar() {
        $locomocaoDAO = new LocomocaoDAO();
        return $locomocaoDAO->list();
    }
}

?>