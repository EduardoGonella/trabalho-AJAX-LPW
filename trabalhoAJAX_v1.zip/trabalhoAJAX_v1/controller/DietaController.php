<?php

require_once( __DIR__ . "/../DAO/DietaDAO.php");

class DietaController {
    
    public function listar() {
        $dietaDAO = new DietaDAO();
        return $dietaDAO->list();
    }
}

?>