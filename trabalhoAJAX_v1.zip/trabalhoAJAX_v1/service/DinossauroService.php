<?php

require_once( __DIR__ . "/../DAO/DinossauroDAO.php");

class DinossauroService {
    public function validar(Dinossauro $dinossauro) {
        $erros = array();
        
        if(!$dinossauro->getNome()) {
            array_push($erros, "Informe o nome!");
        } else if (strlen($dinossauro->getNome()) < 2) {
            array_push($erros, "Nome muito pequeno. Informe um nome válido!");
        } else if (strlen($dinossauro->getNome()) > 70) {
            array_push($erros, "Nome muito grande. Informe um nome válido!");
        }
        
        if(!$dinossauro->getAltura()) {
            array_push($erros, "Informe a altura!");
        } else if ($dinossauro->getAltura() <= 0 or $dinossauro->getAltura() > 20.00) {
            array_push($erros, "Dinossauro com essa altura não existe. Informe uma altura válida!");
        }
        
        if(!$dinossauro->getComprimento()) {
            array_push($erros, "Informe o comprimento!");
        } else if ($dinossauro->getComprimento() <= 0 or $dinossauro->getComprimento() > 42.00) {
            array_push($erros, "Dinossauro com esse comprimento não existe. Informe um comprimento válido!");
        }

        if(!$dinossauro->getVelocidade()) {
            array_push($erros, "Informe a velocidade!");
        } else if($dinossauro->getVelocidade() <= 0 or $dinossauro->getVelocidade() > 80) {
            array_push($erros, "Dinossauro com essa velocidade não existe. Informe uma velocidade válida!");
        }

        if(!$dinossauro->getidDieta()->getId()) {
                array_push($erros, "Informe a dieta!");
        }

        if(!$dinossauro->getIdLocomocao()->getId()) {
                array_push($erros, "Informe a locomocao!");
        }

        if(!$dinossauro->getIdPeriodo()->getId()) {
                array_push($erros, "Informe o periodo!");
        }
        
        if(!$dinossauro->getFoto()) {
            array_push($erros, "Informe a URL da foto!");
        } else if (strlen($dinossauro->getFoto()) < 2) {
            array_push($erros, "URL muito pequena. Informe uma URL válida!");
        } else if (strlen($dinossauro->getFoto()) > 150) {
            array_push($erros, "URL muito grande. Informe uma URL válida!");
        }

        return $erros;
    }
}