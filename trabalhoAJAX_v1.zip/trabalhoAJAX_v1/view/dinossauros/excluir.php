<?php

require_once(__DIR__ . "/../../controller/DinossauroController.php");

if(isset($_GET['id'])) {
    $id_excluir = $_GET['id'];

    $dinossauroCont = new DinossauroController();
    $erro = $dinossauroCont->excluir($id_excluir);

    if(! $erro) {
        header("location: listar.php");  
    } else {
        echo $erro;
        echo "<br><a href='listar.php'>Voltar</a>";
    }
    
    
} else {
    echo "ID do dinossauro não informado!<br>";
    echo "<a href='listar.php'>Voltar</a>";
}

