<?php

require_once(__DIR__ . "/../../controller/DietaController.php");
require_once(__DIR__ . "/../../controller/LocomocaoController.php");
require_once(__DIR__ . "/../../controller/PeriodoController.php");

$dietaCont = new DietaController();
$dietas = $dietaCont->listar();

$locomocaoCont = new LocomocaoController();
$locomocaos = $locomocaoCont->listar();

$periodoCont = new PeriodoController();
$periodos = $periodoCont->listar();

require_once(__DIR__ . "/../include/header.php");

require_once(__DIR__ . "/../include/menu.php");
?>

<h3><?= $dinossauro && $dinossauro->getId() > 0 ? "Alterar" : "Inserir" ?> dinossauro</h3>

<div class="row">

    <div class="col-6">

        <form action="" method="POST">

            <div>
                <label for="txtNome" class="form-label">Nome: </label>
                <input type="text" id="txtNome" name="nome" 
                    placeholder="Informe o nome" 
                    class="form-control"
                    value="<?= $dinossauro ? $dinossauro->getNome() : '' ?>">
            </div>

            <div>
                <label for="txtAltura" class="form-label">Altura (m): </label>
                <input type="number" id="txtAltura" name="altura" 
                    placeholder="Informe a altura" class="form-control" step="0.01"
                    value="<?= $dinossauro ? $dinossauro->getAltura() : '' ?>">
            </div>

            <div>
                <label for="txtComprimento" class="form-label">Comprimento (m): </label>
                <input type="number" id="txtComprimento" name="comprimento" 
                    placeholder="Informe o comprimento" class="form-control" step="0.01"
                    value="<?= $dinossauro ? $dinossauro->getComprimento() : '' ?>">
            </div>

            <div>
                <label for="txtVelocidade" class="form-label">Velocidade (km/h): </label>
                <input type="number" id="txtVelocidade" name="velocidade" 
                    placeholder="Informe a velocidade" class="form-control"
                    value="<?= $dinossauro ? $dinossauro->getVelocidade() : '' ?>">
            </div>

            <div>
                <label for="selDieta" class="form-label">Dieta: </label>
                <select name="id_dieta" id="selDieta" class="form-select">
                    <option value="">----Selecione-----</option>
                    <?php foreach($dietas as $d): ?>
                        <option value="<?= $d->getId() ?>"
                            <?php 
                                if($dinossauro && $dinossauro->getIdDieta()->getId() == $d->getId())
                                    echo "selected";
                            ?>
                        >
                        <?= $d->getDietaDesc() ?></option>        
                    <?php endforeach; ?>    
                </select>
            </div>

            <div>
                <label for="selLocomocao" class="form-label">Locomoção: </label>
                <select name="id_locomocao" id="selLocomocao" class="form-select">
                    <option value="">----Selecione-----</option>
                    <?php foreach($locomocaos as $l): ?>
                        <option value="<?= $l->getId() ?>"
                            <?php 
                                if($dinossauro && $dinossauro->getIdLocomocao()->getId() == $l->getId())
                                    echo "selected";
                            ?>
                        >
                        <?= $l->getLocomocaoDesc() ?></option>        
                    <?php endforeach; ?>    
                </select>
            </div>

            <div>
                <label for="selPeriodo" class="form-label">Período: </label>
                <select name="id_periodo" id="selPeriodo" class="form-select">
                    <option value="">----Selecione-----</option>
                    <?php foreach($periodos as $p): ?>
                        <option value="<?= $p->getId() ?>"
                            <?php 
                                if($dinossauro && $dinossauro->getIdPeriodo()->getId() == $p->getId())
                                    echo "selected";
                            ?>
                        >
                        <?= $p->getPeriodoDesc() ?></option>        
                    <?php endforeach; ?>    
                </select>
            </div>
            
            <div>
                <label for="txtFoto" class="form-label">Foto (URL): </label>
                <input type="text" id="txtFoto" name="foto" 
                    placeholder="Informe a URL da foto" class="form-control"
                    value="<?= $dinossauro ? $dinossauro->getFoto() : '' ?>">
            </div>

            <div>
                <input type="hidden" name="id" 
                    value="<?= $dinossauro ? $dinossauro->getId() : 0 ?>">
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-success">Gravar</button>
            </div>
        </form>

    </div>

    <div class="col-6">
        <?php if($msgErro): ?>
            <div class="alert alert-danger mt-3">
                <?= $msgErro ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<a href="listar.php" class="btn btn-outline-secondary mt-3">Voltar</a>

<?php
require_once(__DIR__ . "/../include/footer.php");
?>