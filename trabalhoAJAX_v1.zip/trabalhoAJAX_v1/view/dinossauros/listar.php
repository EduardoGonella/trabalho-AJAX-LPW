<?php

require_once(__DIR__ . "/../../controller/DinossauroController.php");

$DinoCont = new DinossauroController();
$Dinossauros = $DinoCont->listar();

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
?>

<h3>Listagem de Dinossauros</h3>

<a href="inserir.php" class="btn btn-primary">Inserir</a>

<table class="table table-striped table-bordered mt-3 text-center">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Altura (m)</th>
        <th>Comprimento (m)</th>
        <th>Velocidade (km/h)</th>
        <th>Dieta</th>
        <th>Locomoção</th>
        <th>Período</th>
        <th>Foto</th>
        <th>Editar</th>
        <th>Excluir</th>
    </tr>

    <?php foreach ($Dinossauros as $d) : ?>
        <tr>
            <td><?= $d->getId(); ?></td>
            <td><?= $d->getNome(); ?></td>
            <td><?= $d->getAltura(); ?></td>
            <td><?= $d->getComprimento(); ?></td>
            <td><?= $d->getVelocidade(); ?></td>
            <td><?= $d->getIdDieta()->getDietaDesc(); ?></td>
            <td><?= $d->getIdLocomocao()->getLocomocaoDesc(); ?></td>
            <td><?= $d->getIdPeriodo()->getPeriodoDesc(); ?></td>
            <td><img src="<?= $d->getFoto(); ?>" alt="foto"></td>

            <td>
                <a href="alterar.php?id=<?= $d->getId() ?>">
                    <img src="../../img/btn_editar.png" alt="">
                </a>
            </td>
            <td>
                <a href="excluir.php?id=<?= $d->getId() ?>" onclick="return confirm('Confirmar exclusão?')">
                    <img src="../../img/btn_excluir.png" alt="">
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php
// Incluir o rodapé da página
require_once(__DIR__ . "/../include/footer.php");
?>