<?php

require_once(__DIR__ . "/../../controller/DinossauroController.php");

$msgErro = "";
$dinossauro = NULL;

$dinossauroCont = new DinossauroController();


if(isset($_POST['nome'])) {

    $id = $_POST["id"];
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $altura = is_numeric($_POST['altura']) ? $_POST['altura'] : NULL;
    $comprimento = is_numeric($_POST['comprimento']) ? ($_POST['comprimento']) : NULL;
    $velocidade = is_numeric($_POST['velocidade']) ? $_POST['velocidade'] : NULL;
    $id_dieta = is_numeric($_POST['id_dieta']) ? $_POST['id_dieta'] : NULL;
    $id_locomocao = is_numeric($_POST['id_locomocao']) ? $_POST['id_locomocao'] : NULL;
    $id_periodo = is_numeric($_POST['id_periodo']) ? $_POST['id_periodo'] : NULL;
    $foto = trim($_POST['foto']) ? trim($_POST['foto']) : NULL;

    $dinossauro = new Dinossauro();
    $dinossauro->setId($id);
    $dinossauro->setNome($nome);
    $dinossauro->setAltura($altura);
    $dinossauro->setComprimento($comprimento);
    $dinossauro->setVelocidade($velocidade);
    $dinossauro->setFoto($foto);
    
    $dieta = new Dieta();
    $dieta->setId($id_dieta);
    $dinossauro->setIdDieta($dieta);
    
    $locomocao = new Locomocao();
    $locomocao->setId($id_locomocao);
    $dinossauro->setIdLocomocao($locomocao);
    
    $periodo = new Periodo();
    $periodo->setId($id_periodo);
    $dinossauro->setIdPeriodo($periodo);

    $erros = $dinossauroCont->alterar($dinossauro);
    
    if(empty($erros)) 
        header("location: listar.php");
    else
        $msgErro = implode("<br>", $erros);
} else {
    $id = 0;
    if(isset($_GET['id']))
        $id = $_GET['id'];
    
    $dinossauro = $dinossauroCont->buscarPorId($id);
    if(! $dinossauro) {
        echo "ID do dinossauro inválido!<br>";
        echo "<a href='listar.php'>Voltar</a>"; 
        exit;
    }
}

require_once(__DIR__ . "/form.php");