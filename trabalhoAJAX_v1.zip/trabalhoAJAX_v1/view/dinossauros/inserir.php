<?php

require_once(__DIR__ . "/../../model/Dinossauro.php");
require_once(__DIR__ . "/../../model/Dieta.php");
require_once(__DIR__ . "/../../model/Locomocao.php");
require_once(__DIR__ . "/../../model/Periodo.php");
require_once(__DIR__ . "/../../controller/DinossauroController.php");

$msgErro = "";
$dinossauro = NULL;

if(isset($_POST['nome'])) {
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $altura = is_numeric($_POST['altura']) ? $_POST['altura'] : NULL;
    $comprimento = is_numeric($_POST['comprimento']) ? $_POST['comprimento'] : NULL;
    $velocidade = is_numeric($_POST['velocidade']) ? $_POST['velocidade'] : NULL;
    $idDieta = is_numeric($_POST['id_dieta']) ? $_POST['id_dieta'] : NULL;
    $idLocomocao = is_numeric($_POST['id_locomocao']) ? $_POST['id_locomocao'] : NULL;
    $idPeriodo = is_numeric($_POST['id_periodo']) ? $_POST['id_periodo'] : NULL;
    $foto = trim($_POST['foto']) ? trim($_POST['foto']) : NULL;

    $dinossauro = new Dinossauro();
    $dinossauro->setId(0);
    $dinossauro->setNome($nome);
    $dinossauro->setAltura($altura);
    $dinossauro->setComprimento($comprimento);
    $dinossauro->setVelocidade($velocidade);
    $dinossauro->setFoto($foto);

    $dieta = new Dieta();
    $dieta->setId($idDieta);
    $dinossauro->setIdDieta($dieta);

    $locomocao = new Locomocao();
    $locomocao->setId($idLocomocao);
    $dinossauro->setIdLocomocao($locomocao);

    $periodo = new Periodo();
    $periodo->setId($idPeriodo);
    $dinossauro->setIdPeriodo($periodo);

    $dinossauroCont = new DinossauroController();
    $erros = $dinossauroCont->inserir($dinossauro);

    if(empty($erros)) 
        header("location: listar.php");
    else
        $msgErro = implode("<br>", $erros);
}

require_once(__DIR__ . "/form.php");
?>