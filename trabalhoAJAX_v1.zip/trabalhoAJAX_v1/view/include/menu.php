<?php
require_once(__DIR__ . "/../../util/config.php");
?>

<nav class="navbar navbar-expand-md navbar-jurassic px-3">
    
    <a class="navbar-brand" href="<?= BASE_URL ?>/index.php">🦖 Enciclopédia Jurássica!</a>

    <button class="navbar-toggler" type="button"
        data-bs-toggle="collapse" data-bs-target="#navSite">
        <span class="navbar-toggler-icon"></span>
    </button>
</nav>