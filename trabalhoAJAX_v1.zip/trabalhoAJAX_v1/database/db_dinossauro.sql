-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 25/11/2026 às 12:29
-- Versão do servidor: 8.0.46-0ubuntu0.24.04.5
-- Versão do PHP: 8.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_dinossauro`
--
CREATE DATABASE IF NOT EXISTS `db_dinossauro` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `db_dinossauro`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `dieta`
--

CREATE TABLE `dieta` (
  `id` int NOT NULL,
  `dieta` varchar(1) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `dieta`
--

INSERT INTO `dieta` (`id`, `dieta`) VALUES
(1, 'C'),
(2, 'H'),
(3, 'O');

-- --------------------------------------------------------

--
-- Estrutura para tabela `dinossauro`
--

CREATE TABLE `dinossauro` (
  `id` int NOT NULL,
  `nome` varchar(70) COLLATE utf8mb4_general_ci NOT NULL,
  `altura` decimal(4,2) NOT NULL,
  `comprimento` decimal(4,2) NOT NULL,
  `velocidade` decimal(4,2) NOT NULL,
  `id_dieta` int NOT NULL,
  `id_locomocao` int NOT NULL,
  `id_periodo` int NOT NULL,
  `foto` varchar(150) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `dinossauro`
--

INSERT INTO `dinossauro` (`id`, `nome`, `altura`, `comprimento`, `velocidade`, `id_dieta`, `id_locomocao`, `id_periodo`, `foto`) VALUES
(8, 'adad', 12.00, 12.12, 65.00, 3, 2, 1, 'https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/025.png');

-- --------------------------------------------------------

--
-- Estrutura para tabela `locomocao`
--

CREATE TABLE `locomocao` (
  `id` int NOT NULL,
  `locomocao` varchar(1) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `locomocao`
--

INSERT INTO `locomocao` (`id`, `locomocao`) VALUES
(1, 'T'),
(2, 'W'),
(3, 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `periodo`
--

CREATE TABLE `periodo` (
  `id` int NOT NULL,
  `periodo` varchar(1) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `periodo`
--

INSERT INTO `periodo` (`id`, `periodo`) VALUES
(1, 'T'),
(2, 'J'),
(3, 'C');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `dieta`
--
ALTER TABLE `dieta`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `dinossauro`
--
ALTER TABLE `dinossauro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_dieta` (`id_dieta`),
  ADD KEY `fk_locomocao` (`id_locomocao`),
  ADD KEY `fk_periodo` (`id_periodo`);

--
-- Índices de tabela `locomocao`
--
ALTER TABLE `locomocao`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `periodo`
--
ALTER TABLE `periodo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `dieta`
--
ALTER TABLE `dieta`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `dinossauro`
--
ALTER TABLE `dinossauro`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `locomocao`
--
ALTER TABLE `locomocao`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `periodo`
--
ALTER TABLE `periodo`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `dinossauro`
--
ALTER TABLE `dinossauro`
  ADD CONSTRAINT `fk_dieta` FOREIGN KEY (`id_dieta`) REFERENCES `dieta` (`id`),
  ADD CONSTRAINT `fk_locomocao` FOREIGN KEY (`id_locomocao`) REFERENCES `locomocao` (`id`),
  ADD CONSTRAINT `fk_periodo` FOREIGN KEY (`id_periodo`) REFERENCES `periodo` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
