<?php

header("Location: view/dinossauros/listar.php");